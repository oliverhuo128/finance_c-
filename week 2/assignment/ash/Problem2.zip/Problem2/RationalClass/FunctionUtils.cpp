#include "FunctionUtils.h" 

#include <iostream>
using namespace OOP;
void OOP::PrintcRational() {
	// TODO ADD THIS  
  
	std::cout << " function PrintcRational!\n";

}; 

void OOP::PrintMixedRational() {
	// TODO ADD THIS
  
	std::cout << " function PrintMixedRational!\n";
};  