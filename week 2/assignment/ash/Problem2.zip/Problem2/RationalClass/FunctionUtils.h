//------------------------------------------------------------------------------
//
// FunctionUtils
// FunctionUtils.h 
//  print for cRational operations are performed through print functions 
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// include guard

#ifndef OOP_UTILRATIONALNUMBER_H
#define OOP_UTILRATIONALNUMBER_H

//------------------------------------------------------------------------------
// include files
#include <iostream>

//------------------------------------------------------------------------------
// namespace definition
namespace OOP {

	void PrintcRational(); // TODO ADD THIS  
	void PrintMixedRational(); // TODO ADD THIS  


}
#endif //OOP_UTILRATIONALNUMBER_H
