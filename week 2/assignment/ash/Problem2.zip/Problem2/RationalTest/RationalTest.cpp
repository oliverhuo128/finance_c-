// Problem2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "../RationalClass/cRational.h" 
#include <iostream>
using namespace OOP;

int main()
{
    std::cout << "Hello RationalTest!\n";
    // ADD tests for cRational inthis RationalTest.cpp


}
 
